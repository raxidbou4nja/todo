<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', '');
  define('DB_NAME', 'mvc');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/projects/mvc');
  // Site Name
  define('SITENAME', 'AjiCode MVC');
  // App Version
  define('APPVERSION', '1.0.0');