<?php require APPROOT . '/views/inc/header.php'; ?>
  <div class="jumbotron jumbotron-flud text-center">
    <div class="container">
    <h1 class="display-3"><?php echo SITENAME; ?></h1>
    </div>
  </div> 
<?php require APPROOT . '/views/inc/footer.php'; ?>
